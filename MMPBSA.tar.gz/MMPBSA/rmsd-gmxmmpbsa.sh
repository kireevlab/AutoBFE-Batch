#!/bin/bash

##SBATCH --mem=10G
##SBATCH --output /dev/null
#SBATCH --job-name=mmpbsa
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --array 0-9
#SBATCH --time 2-00:00:00

module load gromacs

arr=(`ls input/`)
input=${arr[$SLURM_ARRAY_TASK_ID]}
folder=input/$input
echo $folder
echo ""
echo "---data processing---"
echo ""
cd $folder


#--- data processing ---
echo Protein_MOL 0 | gmx_mpi trjconv -s md.tpr -f md.xtc -o md_nopbc.xtc -pbc nojump -center -n index.ndx
# RMSD Backbone and Ligand
echo 4 1 |  gmx_mpi rms -s em0.tpr -f md_nopbc.xtc -o rmsd_prot -tu ns
echo MOL MOL |  gmx_mpi rms -s em0.tpr -f md_nopbc.xtc -o rmsd_lig -tu ns
rm \#* step* slurm*out
rm em0.trr em0.log em0.edr mdout.mdp
rm nvt0.xtc nvt0.log nvt0.edr nvt0.cpt
rm npt0.xtc npt0.log npt0.edr npt0.cpt


echo "--- MM/PB(GB)SA calculation ---"
#---- MMPBSA calculation ----
echo Protein_MOL | gmx_mpi trjconv -s md.tpr -f md_nopbc.xtc -o md_pbsa.xtc -b 4000 -dt 1 -n index.ndx
rm md_nopbc.xtc
# generate ligand.mol2
gmx_mpi editconf -f com.gro -o com.pdb
grep MOL com.pdb | grep -v TITLE > lig.pdb 
python3 ../../pdb2mol2.py
rm com.pdb lig.pdb
mkdir bfe-withEntropy-IE
mkdir bfe-withEntropy-nmode

#######################
module load conda
eval "$(conda shell.bash hook)"
conda activate gmxMMPBSA
#######################
#
# entropy - IE
#
echo "--- MM/PB(GB)SA calculation with entropy IE---"
cd bfe-withEntropy-IE
gmx_MMPBSA -O -i ../../../mmpbsa-IE.in -cs ../md.tpr -ci ../index.ndx -cg 1 13 -ct ../md_pbsa.xtc -lm ../ligand.mol2 -o MMPBSA_BFE_IE.dat -eo MMPBSA_BFE_IE.csv 
rm _GMXMMPBSA_*
rm COMPACT_MMXSA_RESULTS.mmxsa *.prmtop COM_traj_0.xtc
#
# entropy - nmode
#
echo "--- MM/PB(GB)SA calculation with entropy normal mode analysis (NMA)---"
cd ../bfe-withEntropy-nmode
gmx_MMPBSA -O -i ../../../mmpbsa-nmode.in -cs ../md.tpr -ci ../index.ndx -cg 1 13 -ct ../md_pbsa.xtc -lm ../ligand.mol2 -o MMPBSA_BFE_nmode.dat -eo MMPBSA_BFE_nmode.csv
rm _GMXMMPBSA_*
echo "---Calculation Completed---"
