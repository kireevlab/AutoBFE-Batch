#!/bin/bash

#SBATCH --job-name=MDGpu
#SBATCH --mem=1G
#SBATCH -p gpu
#SBATCH --gres gpu:A100:1
#SBATCH --time=4:00:00
#SBATCH --ntasks-per-node=8
#SBATCH --cpus-per-task=1
#SBATCH --array 0-9


module load gromacs/2022.5_gcc_9.5.0_openmpi_4.1.5_cuda

arr=(`ls input/`)
input=${arr[$SLURM_ARRAY_TASK_ID]}
folder=input/$input
cd $folder
echo $folder
echo '========start MD simulations========'
#========start MD simulations============
gmx_mpi editconf -f com.gro -o newbox.gro -c -d 1.0 -bt cubic 
gmx_mpi solvate -cp newbox.gro -cs spc216.gro -o solv.gro -p topol.top
gmx_mpi grompp -f  ../../MD-gmx-mdp/ions.mdp -c solv.gro -p topol.top -o ions.tpr -maxwarn 1
echo SOL | gmx_mpi genion -s ions.tpr -p topol.top -pname NA -nname CL -neutral -o ions.gro -conc 0.15
gmx_mpi grompp -f  ../../MD-gmx-mdp/minim.mdp -c ions.gro -p topol.top -o em0.tpr -maxwarn 1
gmx_mpi mdrun -v -deffnm em0 
gmx_mpi make_ndx -f em0.gro <<EOF
1 | 13
q
EOF
gmx_mpi grompp -f  ../../MD-gmx-mdp/nvt0.mdp -c em0.gro -r em0.gro -p topol.top -o nvt0.tpr -maxwarn 1 -n index.ndx
gmx_mpi mdrun -v -deffnm nvt0 -update gpu -nb gpu -bonded gpu -pme gpu 
gmx_mpi grompp -f  ../../MD-gmx-mdp/npt0.mdp -c nvt0.gro -r nvt0.gro -t nvt0.cpt -p topol.top -o npt0.tpr -maxwarn 1 -n index.ndx 
gmx_mpi mdrun -v -deffnm npt0 -update gpu -nb gpu -bonded gpu -pme gpu
gmx_mpi grompp -f  ../../MD-gmx-mdp/md.mdp -c npt0.gro -t npt0.cpt -p topol.top -o md.tpr -maxwarn 1 -n index.ndx
gmx_mpi mdrun -v -deffnm md -update gpu -nb gpu -bonded gpu -pme gpu 
#========end MD simulations============
echo '========end MD simulations========'
