#!/bin/bash

#SBATCH --mem=1G
#SBATCH --time 10:00
#SBATCH --array 0-9
#SBATCH --output /dev/null

module load amber

arr=(`ls *.log`)
inp=${arr[$SLURM_ARRAY_TASK_ID]}
output=(`echo "$inp" | awk -F '.' '{print$1}'`)
mkdir $output
cp $inp $output/lig.log

# produce many files including .ac file
cd $output/
antechamber -i lig.log -fi gout -o lig.mol2 -fo mol2 -pf y -c resp
parmchk2 -i lig.mol2 -f mol2 -o lig.frcmod
tleap -f ../leap.in
python2.7 ../acpype.py -p lig.prmtop -x lig.inpcrd -d
cp MOL_GMX.top MOL.itp

# delete invalid lines
line=(`wc -l MOL.itp`)
var=(`echo $(($line-5))`)
sed -i "$var,/$line/d" MOL.itp
sed -i '1,8d' MOL.itp
# convert lower to upper case
sed -i 's/ br / Br /g' MOL.itp
sed -i 's/ c / C /g' MOL.itp
sed -i 's/ c1 / C1 /g' MOL.itp
sed -i 's/ c2 / C2 /g' MOL.itp
sed -i 's/ c3 / C3 /g' MOL.itp
sed -i 's/ ca / CA /g' MOL.itp
sed -i 's/ cc / CC /g' MOL.itp
sed -i 's/ cd / CD /g' MOL.itp
sed -i 's/ ce / CE /g' MOL.itp
sed -i 's/ cf / CF /g' MOL.itp
sed -i 's/ cg / CG /g' MOL.itp
sed -i 's/ ch / CH /g' MOL.itp
sed -i 's/ cl / Cl /g' MOL.itp
sed -i 's/ cp / CP /g' MOL.itp
sed -i 's/ cq / CQ /g' MOL.itp
sed -i 's/ cu / CU /g' MOL.itp
sed -i 's/ cx / CX /g' MOL.itp
sed -i 's/ cy / CY /g' MOL.itp
sed -i 's/ f / F /g' MOL.itp
sed -i 's/ h1 / H1 /g' MOL.itp
sed -i 's/ h2 / H2 /g' MOL.itp
sed -i 's/ h3 / H3 /g' MOL.itp
sed -i 's/ h4 / H4 /g' MOL.itp
sed -i 's/ h5 / H5 /g' MOL.itp
sed -i 's/ ha / HA /g' MOL.itp
sed -i 's/ hc / HC /g' MOL.itp
sed -i 's/ hn / HN /g' MOL.itp
sed -i 's/ ho / HO /g' MOL.itp
sed -i 's/ hs / HS /g' MOL.itp
sed -i 's/ hx / HX /g' MOL.itp
sed -i 's/ i / I /g' MOL.itp
sed -i 's/ n / N /g' MOL.itp
sed -i 's/ n1 / N1 /g' MOL.itp
sed -i 's/ n2 / N2 /g' MOL.itp
sed -i 's/ n3 / N3 /g' MOL.itp
sed -i 's/ n4 / N4 /g' MOL.itp
sed -i 's/ na / NA /g' MOL.itp
sed -i 's/ nb / NB /g' MOL.itp
sed -i 's/ nc / NC /g' MOL.itp
sed -i 's/ nd / ND /g' MOL.itp
sed -i 's/ ne / NE /g' MOL.itp
sed -i 's/ nf / NF /g' MOL.itp
sed -i 's/ nh / NH /g' MOL.itp
sed -i 's/ nj / NJ /g' MOL.itp
sed -i 's/ nl / NL /g' MOL.itp
sed -i 's/ nn / NN /g' MOL.itp
sed -i 's/ no / NO /g' MOL.itp
sed -i 's/ o / O /g' MOL.itp
sed -i 's/ oh / OH /g' MOL.itp
sed -i 's/ oq / OQ /g' MOL.itp
sed -i 's/ os / OS /g' MOL.itp
sed -i 's/ s / S /g' MOL.itp
sed -i 's/ s6 / S6 /g' MOL.itp
sed -i 's/ sh / SH /g' MOL.itp
sed -i 's/ ss / SS /g' MOL.itp
sed -i 's/ sx / SX /g' MOL.itp
sed -i 's/ sy / SY /g' MOL.itp
sed -i 's/ p5 / P5 /g' MOL.itp

grep 'Br       Br \|C        C  \|C1       C1 \|C2       C2 \|C3       C3 \|CA       CA \|CC       CC \|CD       CD \|CE       CE \|CF       CF \|CG       CG \|CH       CH \|Cl       Cl \|CP       CP \|CQ       CQ \|CU       CU \|CX       CX \|CY       CY \|F        F  \|H1       H1 \|H2       H2 \|H3       H3 \|H4       H4 \|H5       H5 \|HA       HA \|HC       HC \|HN       HN \|HO       HO \|HS       HS \|HX       HX \|I        I  \|N        N  \|N1       N1 \|N2       N2 \|N3       N3 \|N4       N4 \|NA       NA \|NB       NB \|NC       NC \|ND       ND \|NE       NE \|NF       NF \|NH       NH \|NJ       NJ \|L       NL \|NN       NN \|NO       NO \|O        O  \|OH       OH \|OQ       OQ \|OS       OS \|S        S  \|S6       S6 \|SH       SH \|SS       SS \|SX       SX \|SY       SY \|P5       P5' MOL.itp >> AtomType.txt

sed -i -e '/Br       Br/d' MOL.itp    
sed -i -e '/C        C /d' MOL.itp    
sed -i -e '/C1       C1/d' MOL.itp    
sed -i -e '/C2       C2/d' MOL.itp    
sed -i -e '/C3       C3/d' MOL.itp    
sed -i -e '/CA       CA/d' MOL.itp    
sed -i -e '/CC       CC/d' MOL.itp    
sed -i -e '/CD       CD/d' MOL.itp    
sed -i -e '/CE       CE/d' MOL.itp    
sed -i -e '/CF       CF/d' MOL.itp    
sed -i -e '/CG       CG/d' MOL.itp    
sed -i -e '/CH       CH/d' MOL.itp    
sed -i -e '/Cl       Cl/d' MOL.itp    
sed -i -e '/CP       CP/d' MOL.itp    
sed -i -e '/CQ       CQ/d' MOL.itp    
sed -i -e '/CU       CU/d' MOL.itp    
sed -i -e '/CX       CX/d' MOL.itp    
sed -i -e '/CY       CY/d' MOL.itp    
sed -i -e '/F        F /d' MOL.itp    
sed -i -e '/H1       H1/d' MOL.itp    
sed -i -e '/H2       H2/d' MOL.itp    
sed -i -e '/H3       H3/d' MOL.itp    
sed -i -e '/H4       H4/d' MOL.itp    
sed -i -e '/H5       H5/d' MOL.itp    
sed -i -e '/HA       HA/d' MOL.itp    
sed -i -e '/HC       HC/d' MOL.itp    
sed -i -e '/HN       HN/d' MOL.itp    
sed -i -e '/HO       HO/d' MOL.itp    
sed -i -e '/HS       HS/d' MOL.itp    
sed -i -e '/HX       HX/d' MOL.itp    
sed -i -e '/I        I /d' MOL.itp    
sed -i -e '/N        N /d' MOL.itp    
sed -i -e '/N1       N1/d' MOL.itp    
sed -i -e '/N2       N2/d' MOL.itp    
sed -i -e '/N3       N3/d' MOL.itp    
sed -i -e '/N4       N4/d' MOL.itp    
sed -i -e '/NA       NA/d' MOL.itp    
sed -i -e '/NB       NB/d' MOL.itp    
sed -i -e '/NC       NC/d' MOL.itp    
sed -i -e '/ND       ND/d' MOL.itp    
sed -i -e '/NE       NE/d' MOL.itp    
sed -i -e '/NF       NF/d' MOL.itp    
sed -i -e '/NH       NH/d' MOL.itp    
sed -i -e '/NJ       NJ/d' MOL.itp    
sed -i -e '/NL       NL/d' MOL.itp    
sed -i -e '/NN       NN/d' MOL.itp    
sed -i -e '/NO       NO/d' MOL.itp    
sed -i -e '/O        O /d' MOL.itp    
sed -i -e '/OH       OH/d' MOL.itp    
sed -i -e '/OQ       OQ/d' MOL.itp    
sed -i -e '/OS       OS/d' MOL.itp    
sed -i -e '/S        S /d' MOL.itp    
sed -i -e '/S6       S6/d' MOL.itp    
sed -i -e '/SH       SH/d' MOL.itp    
sed -i -e '/SS       SS/d' MOL.itp    
sed -i -e '/SX       SX/d' MOL.itp    
sed -i -e '/SY       SY/d' MOL.itp    

echo '; Include Position restraint file' >> MOL.itp
echo '#ifdef POSRES' >> MOL.itp
echo '#include "posre_MOL.itp"' >> MOL.itp
echo '#endif' >> MOL.itp
