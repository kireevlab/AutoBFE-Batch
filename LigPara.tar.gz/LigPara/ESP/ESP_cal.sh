#!/bin/bash -
#-------------------------------------------------------------------------------
#  SBATCH CONFIG
#-------------------------------------------------------------------------------
## resources
#SBATCH -N1  # nodes
#SBATCH -n4  # tasks (cores)
#SBATCH --ntasks-per-node=4  # how many tasks per node
#SBATCH --mem-per-cpu=10G  # memory required per core
#SBATCH -t 4:00:00  # time (days-hours:minutes)
#
## housekeeping
##SBATCH -o gauss_%j.out  # filename for the output from this job (%j is the job#)
##SBATCH --output /dev/null
##SBATCH --error slurm.err
#SBATCH -J gauss_opt  # job name - shows up in sacct and squeue
#-------------------------------------------------------------------------------

## Load the Gaussian Module
module load gaussian/16-C.02-avx2
mkdir  /local/scratch/xwpnp

## Run Gaussian
gaussinput=$1
g16 $gaussinput

