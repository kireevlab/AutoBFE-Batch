#!/bin/bash

# activate obabel envioment
module load miniconda3
eval "$(conda shell.bash hook)"
conda activate obabel

finput=$1
charge=$2

# Convert SDF file to individual XYZ files
obabel -isdf $finput -oxyz -Olig.xyz -m

# Count the number of ligands in the SDF file
fnum=$(grep -c 'M  END' $finput)

# Loop through each ligand and process it
for ((i=1; i<=fnum; i++))
do
  file=lig$i.xyz
  new=$(head -n 2 "$file" | tail -n 1 | awk -F '_' '{print $1}')
  # Rename the ligand file with the extracted ligand ID
  mv "$file" "${new}.xyz"

  # Generate Gaussian input file
  sed -n '3,$p' "${new}.xyz" > "${new}_tmp"
  {
    echo "%nproc=4"
    echo "%mem=1GB"
    echo "%chk=esp-tmp-${new}.chk"
    echo "#p hf/6-31G* pop=mk iop(6/33=2,6/42=6)"
    echo ""
    echo "ESP charges calculation"
    echo ""
    echo "${charge} 1"
    cat "${new}_tmp"
    echo ""
    echo ""
    echo ""
  } > "${new}.gjf"

  # Clean up temporary file
  rm "${new}_tmp"
  sbatch ESP_cal.sh $new
done

echo "Gaussian input files were converted."
