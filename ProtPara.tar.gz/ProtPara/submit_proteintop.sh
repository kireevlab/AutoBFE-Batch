#!/bin/bash

#SBATCH --mem=1G
#SBATCH --output /dev/null
#SBATCH --job-name=MD
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=1
#SBATCH --array 0-9
#SBATCH -p dkhf3-lab
#SBATCH -A dkhf3-lab

module load gromacs

# upload all prepared proteins into prepared_proteins/ dir.
arr=(`ls prepared_proteins/*.pdb`)
input=${arr[$SLURM_ARRAY_TASK_ID]}
prefix=(`echo "$input" | awk -F '/' '{print$2}' | awk -F '.' '{print$1}'`)
## Set up AMBER14SB ff enviroment variable, otherwise copy amber14sb_parmbsc1.ff to working dir.
#cp -r amber14sb_parmbsc1.ff $prefix
cd $prefix
echo 1 | gmx_mpi pdb2gmx -f ../$input -o prot.gro -water tip3p -ignh
echo 2 | gmx_mpi genrestr -f MOL_GMX.gro -o posre_MOL.itp -fc 1000 1000 1000	 

sed -i '/Include water topology/i\#include "MOL.itp"\n' topol.top
#
#------------------------------------------------
# insert parameters into the protein withOUT ions
#------------------------------------------------
#
sed -i '/moleculetype/i\[ atomtypes ]\n;name   bond_type     mass     charge   ptype   sigma         epsilon       Amb\n  C3       C3          0.00000  0.00000   A     3.39967e-01   4.57730e-01 ; 1.91  0.1094\n  CF       CF          0.00000  0.00000   A     3.39967e-01   3.59824e-01 ; 1.91  0.0860\n  CG       CG          0.00000  0.00000   A     3.39967e-01   8.78640e-01 ; 1.91  0.2100\n  CH       CH          0.00000  0.00000   A     3.39967e-01   8.78640e-01 ; 1.91  0.2100\n  HN       HN          0.00000  0.00000   A     1.06908e-01   6.56888e-02 ; 0.60  0.0157\n  HX       HX          0.00000  0.00000   A     1.95998e-01   6.56888e-02 ; 1.10  0.0157\n  N1       N1          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  N4       N4          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  ND       ND          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NE       NE          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NF       NF          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NH       NH          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NJ       NJ          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NL       NL          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NN       NN          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NO       NO          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  OQ       OQ          0.00000  0.00000   A     3.00001e-01   7.11280e-01 ; 1.68  0.1700\n  S6       S6          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n  SS       SS          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n  SX       SX          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n  SY       SY          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n' topol.top  
#
#------------------------------------------------
# insert parameters into the protein with ions
#------------------------------------------------
#
#sed -i '/Include chain topologies/i\[ atomtypes ]\n;name   bond_type     mass     charge   ptype   sigma         epsilon       Amb\n  C3       C3          0.00000  0.00000   A     3.39967e-01   4.57730e-01 ; 1.91  0.1094\n  CF       CF          0.00000  0.00000   A     3.39967e-01   3.59824e-01 ; 1.91  0.0860\n  CG       CG          0.00000  0.00000   A     3.39967e-01   8.78640e-01 ; 1.91  0.2100\n  CH       CH          0.00000  0.00000   A     3.39967e-01   8.78640e-01 ; 1.91  0.2100\n  HN       HN          0.00000  0.00000   A     1.06908e-01   6.56888e-02 ; 0.60  0.0157\n  HX       HX          0.00000  0.00000   A     1.95998e-01   6.56888e-02 ; 1.10  0.0157\n  N1       N1          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  N4       N4          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  ND       ND          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NE       NE          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NF       NF          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NH       NH          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NJ       NJ          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NL       NL          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NN       NN          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  NO       NO          0.00000  0.00000   A     3.25000e-01   7.11280e-01 ; 1.82  0.1700\n  OQ       OQ          0.00000  0.00000   A     3.00001e-01   7.11280e-01 ; 1.68  0.1700\n  S6       S6          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n  SS       SS          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n  SX       SX          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n  SY       SY          0.00000  0.00000   A     3.56359e-01   1.04600e+00 ; 2.00  0.2500\n' topol.top  

echo 'MOL                 1' >> topol.top

#------------------------------------------------
# Combine ligand and protein into one com.gro file 
#------------------------------------------------
sed "s|pdbid|$prefix|g" ../CombineProtLigMD.py > CombineProtLigMD_$prefix\.py 
chmod +x CombineProtLigMD_$prefix\.py
./CombineProtLigMD_$prefix\.py
rm ./CombineProtLigMD_$prefix\.py
